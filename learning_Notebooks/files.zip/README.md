# Multi-Agent Research System (Supervisor + MCP + LangGraph)

## المحتوى
- `AI_MultiAgent_MCP.ipynb` — النوتبوك الرئيسي (كل الإيجنتس + السوبرفايزر + الـ graph).
- `mcp_server/search_server.py` — سيرفر MCP منفصل فيه أداة `search_web` حقيقية (بدون API key، عن طريق مكتبة `ddgs`).

## طريقة التشغيل

### 1. جهّز البيئة
```bash
pip install -r requirements.txt
```

### 2. شغّل Ollama وحمّل الموديل
```bash
ollama pull qwen2.5:3b
```
تأكد إن Ollama نفسه شغال (`ollama serve` أو بيشتغل تلقائي حسب نظامك).

### 3. شغّل سيرفر الـ MCP (سيبه شغال في terminal منفصل)
```bash
python mcp_server/search_server.py
```
لازم تستنى تشوف:
```
Uvicorn running on http://0.0.0.0:8000
```

### 4. افتح النوتبوك وشغّله سيل بعد سيل
```bash
jupyter notebook AI_MultiAgent_MCP.ipynb
```

## المعمارية
```
START → Supervisor ⇄ (Research | Extraction | Analysis | Reviewer | Summary) → END
```

- **Supervisor**: بيقرر الإيجنت الجاي عن طريق LLM (structured output)، لكن أي قرار
  بيتفحص أولاً بمنطق حتمي (`is_eligible` / `compute_fallback_agent`) قبل ما ينفذ.
  لو الموديل الصغير اقترح قرار مخالف لحد إيجنت أو لترتيب الـ pipeline، بيتصحح
  تلقائيًا — فمفيش أي احتمال لـ infinite loop أو تخطي مرحلة أساسية.
- **الحدود لكل إيجنت** (`AGENT_LIMITS`):
  - research: 3 محاولات
  - extraction: مرة واحدة
  - analysis: محاولتين (بيتحسن لو المراجع طلب NEEDS_MORE)
  - reviewer: محاولتين
  - summary: مرة واحدة
- **best_analysis / best_review**: بيحتفظوا بآخر (وأفضل) نسخة توصل لها المشروع،
  عشان لو أي إيجنت وصل لحده الأقصى، الإيجنت اللي بعده يستخدم أحدث نتيجة متاحة
  بدل ما يستنى نتيجة "مثالية" مش هتيجي.

## إصلاحات جوهرية عن النسخة الأولى اللي بعتها
1. **edges ناقصة**: كل إيجنت دلوقتي بيرجع للسوبرفايزر بعد ما يخلص
   (`add_edge(agent, "supervisor")`) — في النسخة الأصلية مكانش فيه أي edge
   بترجع من الإيجنتس للسوبرفايزر، فكان المشروع هيقف بعد أول إيجنت لوحده.
2. **`supervisor_agent` غير معرّف**: كان فيه كود بينادي على دالة اسمها
   `supervisor_agent` مش معرّفة في أي مكان — كان هيدي `NameError`.
3. **الثوابت (`MAX_STEPS`, `MAX_RESEARCH_ITERATIONS`) معرّفة ومش مستخدمة**:
   دلوقتي بقى فيه `AGENT_LIMITS` فعلي بيتفرض على كل إيجنت.
2. **duplicate edges**: كان فيه `add_edge(START, "supervisor")` مكرر مرتين.
5. **مفيش أي حماية من فشل الـ structured output**: لو الموديل الصغير رجّع
   حاجة مش متوافقة مع الـ schema، دلوقتي فيه `try/except` بيمنع توقف المشروع.
